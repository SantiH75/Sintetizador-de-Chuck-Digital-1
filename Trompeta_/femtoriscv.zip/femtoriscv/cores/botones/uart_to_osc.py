import serial
from pythonosc import udp_client

# Configuración
PORT_UART = '/dev/ttyUSB0'  # Reemplaza con tu puerto UART
BAUDRATE = 115200
OSC_PORT = 6449

# Inicializa OSC
osc_client = udp_client.SimpleUDPClient("127.0.0.1", OSC_PORT)

# Abre conexión UART
ser = serial.Serial(PORT_UART, BAUDRATE)

print("Escuchando UART... Enviando OSC a ChucK.")

while True:
    data = ser.read(1)  # Lee 1 byte
    nota = int.from_bytes(data, 'little') & 0x07  # Filtra 3 bits
    print(f"Nota recibida: {nota}")
    osc_client.send_message("/nota", nota)
