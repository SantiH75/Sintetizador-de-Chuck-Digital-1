#ifndef TIME_H
#define TIME_H

#include <stdint.h>

void wait(uint32_t cycles);

#endif
